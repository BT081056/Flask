# -*- coding: utf-8 -*-
"""
Created on Fri Sep 16 07:05:23 2022

@author: user
"""
from flask import *
app = Flask(__name__)

@app.route('/test_api/', methods=['GET'])
def test_api_2():
    return jsonify(message='Hello, API')

@app.route('/upload/', methods=['POST'])
def upload_2():
    data2 = json.loads(request.data)
    return data2['data']

@app.route('/')
def index():
    data=[{'name': 'rose 1', 'value': 40},
        {'name': 'rose 2', 'value': 38},
        {'name': 'rose 3', 'value': 32},
        {'name': 'rose 4', 'value': 18}]
    return render_template("index.html", data=data)

if __name__ == "__main__":
    app.run(host='0.0.0.0', debug=True, port=8000)
    
    