# -*- coding: utf-8 -*-
"""
Created on Sat Aug 20 12:20:57 2022

@author: user
https://medium.com/%E5%B7%A5%E7%A8%8B%E9%9A%A8%E5%AF%AB%E7%AD%86%E8%A8%98/flask-echarts-%E8%B3%87%E6%96%99%E8%A6%96%E8%A6%BA%E5%8C%96-52e0784e1b7d

https://echarts.apache.org/examples/zh/editor.html?c=candlestick-large
"""

import numpy as np




# jurl = 'https://data.wra.gov.tw/Service/OpenData.aspx?format=json&id=2D09DB8B-6A1B-485E-88B5-923A462F475C'

# from urllib.request import urlopen
  
# import json
# # store the response of URL
# response = urlopen(jurl)
  
# # storing the JSON response 
# # from url in data
# data_json = json.loads(response.read())
  
# # print the json response
# print(data_json)

# for a in data_json.keys():
#     for a2 in data_json[a]:
#         print(a,a2['WaterLevel'])

# ee

def r20(n):
    data = []
    for i in range(n):
        data.append(np.random.randint(40))
    return data
    


import datetime

data = []

for i in range(20):
    
    year, month, day, hh, mm, ss = 2022, 8, 4, 3, 4,30
    day = i + 1
    # print(day)
    dt = datetime.datetime(year, month, day, hh, mm,ss)
    DT = datetime.datetime.strftime(dt,('%Y-%m-%d %H:%H:%S'))
    source = r20(np.random.randint(30,40))
    datalen = len(source)
    datamax = int(np.max(source))
    datamin = int(np.min(source))
    dataopen = int(np.mean(source))
    dataclose = int(np.percentile(source,(50)))
    data.append([DT,dataopen,datamax,dataclose,datamin,datalen,-1])
    
# print(data)
    # data[1] = [DT,20,30,40,30,20,-1]

# 		data[i] = [
# 		  echarts.format.formatTime('yyyy-MM-dd\nhh:mm:ss', (xValue += minute)),
# 		  +boxVals[openIdx].toFixed(2),
# 		  +boxVals[3].toFixed(2),
# 		  +boxVals[0].toFixed(2),
# 		  +boxVals[closeIdx].toFixed(2),
# 		  +volumn.toFixed(0),
# 		  getSign(data, i, +boxVals[openIdx], +boxVals[closeIdx], 4) // sign
# 		];
from flask import *
app = Flask(__name__)

@app.route('/test_api/', methods=['GET'])
def test_api():
    return jsonify(message='Hello, API')

@app.route('/')
def index():
    # data=[{'name': 'rose 1', 'value': 40},
    #     {'name': 'rose 2', 'value': 38},
    #     {'name': 'rose 3', 'value': 32},
    #     {'name': 'rose 4', 'value': 30},
    #     {'name': 'rose 5', 'value': 28},
    #     {'name': 'rose 6', 'value': 26},
    #     {'name': 'rose 7', 'value': 22},
    #     {'name': 'rose 8', 'value': 18}]
    return render_template("index.html", data=data)

if __name__ == "__main__":
    app.run(host='0.0.0.0', debug=True, port=8000)