# -*- coding: utf-8 -*-
"""
Created on Fri Sep 16 08:23:13 2022

@author: user

"""
import json
import requests

headers = {'Content-Type': "application/json,text/plain",'Accept': "*/*"}
payload = json.dumps({
    "data": {
    "columns": 123,
    "index": 456,
    "data": 785
  },

  "parameters": {
    "n_neighbors": 20,
    "contamination": "auto",
    "leaf_size": 30
  }
    })

response = requests.request("POST", "http://192.168.53.171:8000/upload/"
                            ,headers=headers, data=payload)

print(response.json())